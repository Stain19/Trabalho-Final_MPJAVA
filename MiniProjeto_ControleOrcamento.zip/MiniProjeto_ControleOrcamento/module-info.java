/**
 * 
 */
/**
 * @author Pedro Henrique Braga de Morais
 *
 *
 */
module mP_ControleOrcamento {
	requires java.desktop;
	requires swingx.all;
}